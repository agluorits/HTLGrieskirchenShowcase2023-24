using UnityEngine;

public class ThirdPersonCamera : MonoBehaviour
{
    //public Transform player;
    public Transform target; // First player's transform
    //public Vector3 offset = new Vector3(0f, 2f, -5f); // Offset from the player
    //public float smoothSpeed = 0.125f; // Smoothness of camera movement

    private const float groundHeight = 9.700002f;

    private Camera mainCamera;

    void Start()
    {
        // Get the main camera component
        mainCamera = GetComponent<Camera>();
    }

    void LateUpdate()
    {

        
            mainCamera.transform.LookAt(target.position);
        
       
    }

    //private bool IsTooHigh()
    //{
    //    return player.transform.position.y > groundHeight;
    //}
}
