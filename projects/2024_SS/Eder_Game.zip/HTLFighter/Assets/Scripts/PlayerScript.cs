using System;
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    public int playerNumber;
    private string m_MovementAxisName;
    private string m_TurnAxisName;

    public float damageTaken = 0;

    public float moveSpeed = 5f;
    public float jumpForce = 5f;
    public float rotationSpeed = 5f; 

    //children of player
    public Transform leftHand;
    public Transform rightHand;
    public Transform launchDirectionTransform;

    public PlayerScript otherPlayer;
    public float currentAttackDamage = 0f;

    private const float groundHeight = 9.71f;

    private Rigidbody rb;
    public Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();

        if (playerNumber == 1)
        {
            m_MovementAxisName = "Vertical";
            m_TurnAxisName = "Horizontal";
        }
        else
        {
            m_MovementAxisName = "Vertical2"; 
            m_TurnAxisName = "Horizontal2"; 
        }

        rb.useGravity = true;

       
    }

    void Update()
    {
        float horizontalInput = Input.GetAxis(m_TurnAxisName);
        float verticalInput = Input.GetAxis(m_MovementAxisName);

        Vector3 moveDirection = new Vector3(horizontalInput, 0f, verticalInput).normalized;

        if(playerNumber ==1) { RotateTowardsMouse(); }
        else {
            RotateWithJoyStick();
               }

        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);

        if (Input.GetButtonDown("Jump" + playerNumber)) 
        {
            
            Jump();
        }

        if (Input.GetButtonDown("Attack" + playerNumber)) 
        {
            if (IsGrounded())
            {
                StartCoroutine(PerformGroundedJabAttack());
            }
            else
            {
                StartCoroutine(PerformAerialStrike());
            }
            
        }

        CheckGrounded();

        AdjustMoveSpeed();

    }

    private void AdjustMoveSpeed()
    {
        if (!animator.GetCurrentAnimatorStateInfo(0).IsName("Hitstun"))
        {
            moveSpeed = 5f;
        }
        else
        {
            moveSpeed = 3f;
        }
    }

    private void CheckGrounded()
    {
        if (IsGrounded())
        {
            return;
        }
        else if (!IsGrounded())
        {
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("Idle"))
            {
                animator.SetTrigger("AerialTrigger");
            }
        }
    }

    void Jump()
    {
        
        if (IsGrounded())
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
    }

    bool IsGrounded()
    {
        return transform.position.y <= groundHeight;
    }

    void RotateTowardsOtherPlayer()
    {
        Vector3 direction = otherPlayer.transform.position - transform.position;
        direction.y = 0f;

        float angle = Vector3.SignedAngle(transform.forward, direction, Vector3.up);

        float rotationAmount = Mathf.Clamp(angle, -rotationSpeed * Time.deltaTime, rotationSpeed * Time.deltaTime);

        animator.applyRootMotion = true;
        transform.Rotate(Vector3.up, rotationAmount);


    }

    void RotateTowardsMouse()
    {
        Vector3 mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(new Vector3(mousePosition.x, mousePosition.y, Camera.main.transform.position.y));

        Vector3 direction = mousePosition - transform.position;
        direction.y = 0f;

        float angle = Vector3.SignedAngle(transform.forward, direction, Vector3.up);

        float rotationAmount = Mathf.Clamp(angle, -rotationSpeed * Time.deltaTime, rotationSpeed * Time.deltaTime);

        transform.Rotate(Vector3.up, rotationAmount);
    }

    void RotateWithJoyStick()
    {
        string RotationAxis = "HorizontalJoystick";

        float rotationInput = Input.GetAxis(RotationAxis);

        // Calculate the rotation amount based on the input and rotation speed
        float rotationAmount = rotationInput * rotationSpeed * Time.deltaTime;

        // Rotate the player around the y-axis
        transform.Rotate(Vector3.up, rotationAmount);
    }

    IEnumerator PerformGroundedJabAttack()
    {
        currentAttackDamage = 3.5f;
        RotateLaunchDireciton(-45f);
       
        animator.SetTrigger("AttackTrigger");

        yield return new WaitForSeconds(animator.GetCurrentAnimatorStateInfo(0).length);

        if (!animator.GetCurrentAnimatorStateInfo(0).IsName("Hitstun"))
        {
            animator.SetTrigger("EndAttackTrigger");
        }

        currentAttackDamage = 3.5f;

    }

    IEnumerator PerformAerialStrike()
    {
        currentAttackDamage = 4f;
        RotateLaunchDireciton(-50);


        animator.SetTrigger("AttackTrigger");

        yield return new WaitForSeconds(animator.GetCurrentAnimatorStateInfo(0).length);

        if (!animator.GetCurrentAnimatorStateInfo(0).IsName("Hitstun"))
        {
            animator.SetTrigger("EndAttackTrigger");
        }

        currentAttackDamage = 4f;

    }


    //private void OnTriggerEnter(Collider other)
    //{
    //    Debug.Log("Debug: Collider entered");

    //    AudioSource clip = GetComponent<AudioSource>();
    //    clip.Play();

    //    if (other.transform.name == "LeftHand" || other.transform.name == "RightHand")
    //    {
    //        currentAttackDamage = 5f;
    //        damageTaken += otherPlayer.currentAttackDamage;

    //        Vector3 launchDirection = otherPlayer.transform.forward.normalized; // Use the forward direction of the other player

    //        // Adjusting the launch direction
    //        float tiltAngle = 45f; // Tilt angle in degrees
    //        Quaternion tiltQuaternion = Quaternion.AngleAxis(tiltAngle, Vector3.forward); // Create a tilt quaternion around the x-axis
    //        launchDirection = tiltQuaternion * launchDirection; // Apply the tilt to the launch direction

    //        float calculatedDamage = 5.0f; // Default value
    //        if (otherPlayer.currentAttackDamage != 0)
    //        {
    //            calculatedDamage = ((damageTaken + 10f) * (otherPlayer.currentAttackDamage) + 10f);
    //        }
    //        rb.AddForce(launchDirection.normalized * calculatedDamage, ForceMode.Impulse);

    //        Debug.Log("Player " + playerNumber + " was hit by the opponent's hand! " +
    //            "Damage: " + otherPlayer.currentAttackDamage +
    //            " Damage Taken: " + damageTaken);

    //    }
    //}

    private void OnTriggerEnter(Collider other)
    {
        AudioSource clip = GetComponent<AudioSource>();
        clip.Play();
        currentAttackDamage = 0f;

        if (other.transform.name == "LeftHand" || other.transform.name == "RightHand")
        {
            
            animator.SetTrigger("HitStunTrigger");

            // Calculate launch direction relative to the attacking player
            //Vector3 launchDirection = otherPlayer.currentAttackDirection;
            //launchDirection.y = 0f;

            damageTaken += otherPlayer.currentAttackDamage*1.2f;
          
            float calculatedDamage = 5.0f; 
            if (otherPlayer.currentAttackDamage != 0)
            {
                calculatedDamage = ((damageTaken + 10f) * (otherPlayer.currentAttackDamage)) / 18f;
            }
            Vector3 launchDirection = otherPlayer.launchDirectionTransform.forward;
           
            rb.AddForce(launchDirection * calculatedDamage, ForceMode.Impulse);
            

            Debug.Log("Player " + playerNumber + " hit the opponent's hand! " +
                      "Damage: " + otherPlayer.currentAttackDamage +
                      " Damage Taken: " + damageTaken);
        }
    }
    
    public void RotateLaunchDireciton(float targetXRotation)
    {
        launchDirectionTransform.SetPositionAndRotation(transform.position, new Quaternion(0, 0, 0, 0));

        launchDirectionTransform.Rotate(targetXRotation, 0, 0);

    }
    
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.name == "Stage")
        {
            animator.SetTrigger("LandingTrigger");
        }
    }


}
